<label for="selectpickerIcons" class="form-label">Status</label>
<select name="status" class="selectpicker w-100 show-tick status" data-live-search="true" id="status" data-icon-base="bx" data-tick-icon="bx-check" data-style="btn-default">
    <option value="1">Aktif</option>
    <option value="0">Tidak Aktif</option>
</select>
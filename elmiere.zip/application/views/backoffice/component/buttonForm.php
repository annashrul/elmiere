<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
<button type="submit" class="btn btn-primary btn-save">Simpan</button>
<button class="btn btn-primary btn-loading" type="button" disabled>
    <span class="spinner-border" role="status" aria-hidden="true"></span>
    Loading...
</button>
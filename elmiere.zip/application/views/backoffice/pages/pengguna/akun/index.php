<?php $data[$this->pages] = 'level';
$data['focus'] = 'name';
$this->load->view($this->generalHeader, $data) ?>

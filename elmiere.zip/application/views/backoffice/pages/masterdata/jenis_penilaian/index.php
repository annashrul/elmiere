<?php $data[$this->pages] = 'jenis-penilaian';
$data['focus'] = 'name';
$this->load->view($this->generalHeader, $data) ?>
